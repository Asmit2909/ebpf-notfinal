#!/usr/bin/env bash
# test_sockmap.sh — bring-up, functional proof, and throughput test.
#
# Requires root + cgroup v2 + a BTF-enabled kernel.
# Tools: bpftool, clang, iperf3, tcpdump.
#
# The functional proof is by ABSENCE: with redirect working, iperf3 moves
# gigabytes while tcpdump on lo sees the handshake but ~zero payload bytes.
#
# NOTE: the object is built by the Makefile (so the CO-RE arch/cpu flags are
# consistent). This script no longer calls clang directly.
set -euo pipefail

OBJ=sockmap_redirect.bpf.o
PIN=/sys/fs/bpf/sm
CG=/sys/fs/cgroup/sockmap_test
PORT=5599
PCAP=/tmp/lo_sockmap.pcap

need(){ command -v "$1" >/dev/null || { echo "missing tool: $1"; exit 1; }; }
need bpftool; need clang; need iperf3; need tcpdump; need make
[ "$(id -u)" -eq 0 ] || { echo "run as root"; exit 1; }

# cgroup v2 sanity: the unified hierarchy must be mounted.
if ! mount | grep -q 'cgroup2 on /sys/fs/cgroup'; then
  echo "ERROR: cgroup v2 not mounted at /sys/fs/cgroup (this test needs unified cgroups)."
  exit 1
fi

# Run whatever follows inside the test cgroup (moves the subshell, then execs).
in_cg(){ ( echo $BASHPID > "$CG/cgroup.procs"; exec "$@" ); }

cleanup(){
  set +e
  bpftool cgroup detach "$CG" sock_ops pinned "$PIN/bpf_sockmap" 2>/dev/null
  rm -rf "$PIN"
  # move ourselves back to root cgroup so the dir can be removed
  echo $$ > /sys/fs/cgroup/cgroup.procs 2>/dev/null
  [ -d "$CG" ] && rmdir "$CG" 2>/dev/null
  sysctl -q -w kernel.bpf_stats_enabled=0
  # tidy any strays
  pkill -f "iperf3 -s -1 -p $PORT" 2>/dev/null
}
trap cleanup EXIT

# --- build (delegated to the Makefile; regenerates vmlinux.h if absent) ------
make --no-print-directory "$OBJ"

# --- baseline throughput BEFORE any redirect ---------------------------------
echo "===== BASELINE (plain loopback TCP) ====="
iperf3 -s -1 -p "$PORT" >/dev/null 2>&1 & sleep 0.4
iperf3 -c 127.0.0.1 -p "$PORT" -t 3 -f g | grep -E "sender|receiver"

# --- load + attach both hooks ------------------------------------------------
rm -rf "$PIN"; mkdir -p "$CG"
sysctl -q -w kernel.bpf_stats_enabled=1        # so run_cnt is populated
bpftool prog loadall "$OBJ" "$PIN" pinmaps "$PIN"
bpftool cgroup attach "$CG" sock_ops pinned "$PIN/bpf_sockmap"
bpftool prog attach pinned "$PIN/bpf_redir" msg_verdict pinned "$PIN/sock_ops_map"
echo "===== ATTACHED ====="
bpftool cgroup show "$CG"

# --- functional run: server + client INSIDE the cgroup, capture lo -----------
# Both endpoints must be in the attached cgroup for both sockets to be hashed.
in_cg iperf3 -s -1 -p "$PORT" >/dev/null 2>&1 & SRV=$!
sleep 0.4
timeout 8 tcpdump -i lo -n -q "tcp port $PORT" -w "$PCAP" >/dev/null 2>&1 & TCP=$!
sleep 0.3
echo "===== REDIRECT (sockmap active) ====="
in_cg iperf3 -c 127.0.0.1 -p "$PORT" -t 3 -f g | grep -E "sender|receiver"
wait "$SRV" 2>/dev/null || true
wait "$TCP" 2>/dev/null || true

# --- evidence ----------------------------------------------------------------
echo "===== sockhash entries (expect >= 2: both directions) ====="
bpftool map dump pinned "$PIN/sock_ops_map" | grep -c '^key' || true

echo "===== sk_msg prog run_cnt (expect > 0) ====="
bpftool prog show pinned "$PIN/bpf_redir" | grep -o 'run_cnt [0-9]*' || \
  echo "run_cnt not shown (is kernel.bpf_stats_enabled=1?)"

echo "===== payload segments observed on lo (expect ~0 if bypassed) ====="
# handshake/FIN are tiny; real data segments carry length > 0.
tcpdump -r "$PCAP" -n 2>/dev/null | grep -Eo 'length [0-9]+' \
  | awk '{s+=$2} END{printf "total payload bytes on lo: %d\n", s+0}'
echo "(compare against the gigabytes iperf3 reported above)"
